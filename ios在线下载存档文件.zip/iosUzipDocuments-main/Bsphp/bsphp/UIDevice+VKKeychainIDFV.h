//
//  UIDevice+VKKeychainIDFV.h
//  VKKeychainIDFV
//
//  Created by Awhisper on 16/5/9.
//  Copyright © 2016年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (VKKeychainIDFV)

-(NSString *)VKKeychainIDFV;

+(NSString *)VKKeychainIDFV;

-(void)removeVKKeychainIDFV;

+(void)removeVKKeychainIDFV;

@end
